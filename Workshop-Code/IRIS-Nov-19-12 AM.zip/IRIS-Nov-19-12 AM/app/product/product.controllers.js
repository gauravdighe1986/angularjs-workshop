angular.module("product.controllers", [])

.directive("validateYear", function() {
    return {
        restrict : 'A',
        require: 'ngModel',
        link: function(scope, elem, attrs, ngModel) {
            ngModel.$validators.validYear = function(modelValue, viewValue) {
                console.log("yearValidator ", modelValue, viewValue)
                var value = modelValue || viewValue;
                try {
                    value = parseInt(value);
                }catch(ex) {
                    return false;
                }
                if (value >= 2010 && value <= 2016) {
                    return true;
                }
                return false;
            }
        }
    }
})

.directive("uniqueNameValidator", function($http, $q) {
    return {
        restrict: 'A',
        require: 'ngModel',

        link: function(scope, elem, attrs, ngModel) {
            ngModel.$asyncValidators.uniqueUsername = function(modelValue, viewValue) {
                var value = modelValue || viewValue;

                // Lookup user by username
                return $http.get('http://localhost:7070/api/exist/products/name/' + value).
                    then(function resolved(response) {
                      //username exists, this means validation fails
                        var data = response.data;

                        if (data.result) {
                            return $q.reject('exists');
                            //return false;
                        }

                        return true;
                    });
                };
        }
    }
})

.controller("ProductListController", function($scope, productService, $filter){
    productService.getProducts()
    .then(function(products){
        $scope.products = products;

        var filterFunc = $filter("byYear");

        var filteredList = filterFunc(products, 2012);
        console.log("filtered lenght ", filteredList.length);
        
    })
})

.controller("ProductEditController", function($scope, $stateParams, productService, $q, $state){
    var id = $stateParams['id'];

    $scope.loading = true;

    if (id) {
        console.log("id", id);

        $q.all([
            productService.getProduct(id),
            productService.getBrands()
        ])
        .then(function(results){
            $scope.product = results[0];
            $scope.brands = results[1];
            $scope.loading = false;
        })
        .catch(function(err) {
            console.error(err);
             $scope.loading = false;
        })
    } else {
        $scope.product = {};

        productService.getBrands()
        .then(function(brands){
            $scope.brands = brands;
             $scope.loading = false;
        })
    }
    /*
    */

    $scope.saveProduct = function() {
        console.log("save ", $scope.product);

        productService.saveProduct($scope.product)
        .then(function(serverReturnedProduct){
            $scope.product = serverReturnedProduct;
        })
    }

    $scope.gotoList = function() {
        $state.go("products.list");
    }
})


.controller("ProductEditResolveController", ["$scope", "product", "brands", "productService", function($scope, product, brands, productService){
    $scope.product = product;
    $scope.brands = brands;

}])
