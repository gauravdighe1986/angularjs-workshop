angular.module("brand.module", [
    "brand.config",
    "brand.services",
    "brand.controllers"
])