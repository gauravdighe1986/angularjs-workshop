"use strict";

angular.module("brand.controllers", [])

//Layout/home page for brand
.controller("BrandLayoutController", function($scope){
    
})

//brandService injected by angular
.controller("BrandListController", function($scope, brandService){
    console.log("BrandListController");

    brandService.getBrands()
    .then(function(brands){
        $scope.brands = brands;
    })
})

.controller("BrandViewController", function($scope, $stateParams,
     brandService){
    console.log($stateParams.id);

    brandService.getBrand($stateParams.id)
    .then(function(brand){
        $scope.brand = brand;
    })
})