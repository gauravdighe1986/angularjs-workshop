angular.module("brand.services", [])

.service("brandService", function($http, apiEndPoint){
    console.log("brandSErvice");

    //REST api
    //GET /api/brands
    this.getBrands = function() {
        return $http.get(apiEndPoint + "/api/brands")
        .then(function(response){
            console.log(response.status, response.data);
            return response.data;
        })
    }

    //GET /api/brands/1
    this.getBrand = function(id) {
        return $http.get(apiEndPoint + "/api/brands/" + id)
        .then(function(response){
            console.log(response.status, response.data);
            return response.data;
        })
    }
})

 