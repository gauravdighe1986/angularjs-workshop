== Action ==
1. Copy below to index.html file

  <script src="app/brand/brand.module.js" type="text/javascript">
  </script>

  <script src="app/brand/brand.config.js" type="text/javascript">
  </script>
  
  <script src="app/brand/brand.controllers.js" type="text/javascript">
  </script>

2. include "brand.module" to app.js