angular.module("about.module", [
    "about.config",
    "about.controllers"
])
