angular.module("about.controllers", [])


.run(function(apiEndPoint){
    console.log("end point at controller ", apiEndPoint);
   
})

.controller("AboutController", function($scope){
    $scope.title = "About Us"; 

    $scope.members = ['Venkat', 'Krish', 'Karthik'];

    $scope.textChanged = function() {
        console.log("text ", $scope.q);
 
    }
})