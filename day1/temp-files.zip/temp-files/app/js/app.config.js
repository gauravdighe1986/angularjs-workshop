angular.module("app.config", [])

.constant("apiEndPoint", "http://localhost:7070")