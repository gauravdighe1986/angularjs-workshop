angular.module("productApp", [
        "ui.router",
        "app.config",

        "about.module",
        "home.module",
        "brand.module"
])

.run(function($rootScope, apiEndPoint){
    console.log("App module run called", apiEndPoint);
    $rootScope.appTitle = "Catalog App";
   
})


.run(function($rootScope){
    console.log("App module run 2 called");
    $rootScope.appTitle = "Catalog App 2";
    
})

.config(function(apiEndPoint){
    console.log("app module config ", apiEndPoint);
})