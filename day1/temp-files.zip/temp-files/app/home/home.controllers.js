angular.module("home.controllers", [])
.controller("HomeController", function($scope){
    $scope.title = 'Home';

    //$scope.$emit("pageTitleChanged", "Home");
})

.config(function(){
    console.log("home controlller  config");
})