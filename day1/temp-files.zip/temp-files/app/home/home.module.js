angular.module("home.module", [
    "home.config",
    "home.controllers"
])